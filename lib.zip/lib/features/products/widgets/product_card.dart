import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../app/theme/app_colors.dart';
import '../../../app/theme/app_radius.dart';
import '../../../app/theme/app_shadows.dart';
import '../../../app/theme/app_spacing.dart';
import '../../../app/theme/app_typography.dart';
import '../../../app/widgets/app_cached_image.dart';
import '../../../app/widgets/app_card.dart';
import '../../../app/widgets/app_price.dart';
import '../../../core/models/product_model.dart';
import '../../cart/providers/cart_provider.dart';
import '../../favorites/providers/favorites_provider.dart';
import '../widgets/product_details_sheet.dart';

class ProductCard extends StatelessWidget {
  final ProductModel product;

  const ProductCard({
    super.key,
    required this.product,
  });

  @override
  Widget build(BuildContext context) {
    final favorites = context.watch<FavoritesProvider>();
    final isFavorite = favorites.isFavorite(product.id);

    return AppCard(
      onTap: () {
        showModalBottomSheet(
          context: context,
          isScrollControlled: true,
          backgroundColor: Colors.transparent,
          builder: (_) => DraggableScrollableSheet(
            expand: false,
            initialChildSize: .92,
            maxChildSize: .96,
            minChildSize: .55,
            builder: (_, __) {
              return Container(
                decoration: BoxDecoration(
                  color: Theme.of(context).colorScheme.surface,
                  borderRadius: BorderRadius.vertical(
                    top: Radius.circular(AppRadius.sheet),
                  ),
                ),
                child: ProductDetailsSheet(
                  product: product,
                ),
              );
            },
          ),
        );
      },
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          //--------------------------------------------------------
          // IMAGE
          //--------------------------------------------------------

          Expanded(
            flex: 13,
            child: Stack(
              children: [
                SizedBox.expand(
                  child: Padding(
                    padding: const EdgeInsets.only(
                      left: AppSpacing.md,
                      right: AppSpacing.md,
                      top: AppSpacing.md,
                    ),
                    child: AppCachedImage(
                      imageUrl: product.image,
                      fit: BoxFit.contain,
                    ),
                  ),
                ),
                if (product.isFlashDeal || product.isBestSeller)
                  PositionedDirectional(
                    top: AppSpacing.sm,
                    end: AppSpacing.sm,
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: AppSpacing.sm,
                        vertical: AppSpacing.xs,
                      ),
                      decoration: BoxDecoration(
                        color: product.isFlashDeal
                            ? AppColors.badgeSale
                            : AppColors.badgeBest,
                        borderRadius: BorderRadius.circular(
                          AppRadius.chip,
                        ),
                      ),
                      child: Text(
                        product.isFlashDeal ? "عرض" : "الأكثر",
                        style: AppTypography.badge,
                      ),
                    ),
                  ),
                PositionedDirectional(
                  top: AppSpacing.sm,
                  start: AppSpacing.sm,
                  child: Material(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(
                      AppRadius.button,
                    ),
                    child: InkWell(
                      borderRadius: BorderRadius.circular(
                        AppRadius.button,
                      ),
                      onTap: () {
                        favorites.toggle(product.id);
                      },
                      child: SizedBox(
                        width: 36,
                        height: 36,
                        child: Icon(
                          isFavorite ? Icons.favorite : Icons.favorite_border,
                          color: isFavorite
                              ? AppColors.favorite
                              : AppColors.textHint,
                          size: 18,
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),

          //--------------------------------------------------------
          // CONTENT
          //--------------------------------------------------------

          Expanded(
            flex: 7,
            child: Padding(
              padding: const EdgeInsets.all(AppSpacing.md),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  if (product.brand.isNotEmpty)
                    Text(
                      product.brand,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: AppTypography.productBrand.copyWith(
                        color: AppColors.textHint,
                      ),
                    ),
                  const SizedBox(
                    height: AppSpacing.xs,
                  ),
                  SizedBox(
                    height: 38,
                    child: Text(
                      product.name,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: AppTypography.productName,
                    ),
                  ),
                  const SizedBox(
                    height: AppSpacing.sm,
                  ),
                  const SizedBox(
                    height: AppSpacing.sm,
                  ),
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Expanded(
                        child: AppPrice(
                          price: product.price,
                          oldPrice: product.oldPrice,
                        ),
                      ),
                      Material(
                        color: Colors.transparent,
                        child: InkWell(
                          borderRadius: BorderRadius.circular(
                            AppRadius.button,
                          ),
                          onTap: () async {
                            final response =
                                await context.read<CartProvider>().add(product);

                            if (!context.mounted) return;

                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(
                                content: Text(
                                  response.isSuccess
                                      ? "تمت إضافة ${product.name}"
                                      : response.message,
                                ),
                              ),
                            );
                          },
                          child: Ink(
                            width: 46,
                            height: 46,
                            decoration: BoxDecoration(
                              color: AppColors.primary,
                              borderRadius: BorderRadius.circular(
                                AppRadius.button,
                              ),
                              boxShadow: AppShadows.subtle,
                            ),
                            child: const Icon(
                              Icons.add_rounded,
                              color: Colors.white,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
